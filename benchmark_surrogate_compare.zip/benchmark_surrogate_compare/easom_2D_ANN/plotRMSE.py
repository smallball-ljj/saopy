import matplotlib.pyplot as plt
import csv
import numpy as np
def read_csv_to_np(file_name):
    """
    read data from .csv and convert to numpy.array
    note: if you use np.loadtxt(), when the data have only one row or one column, the loaded data is not in the desired shape
    """
    csv_reader = csv.reader(open(file_name))
    csv_data = []
    for row in csv_reader:
        csv_data.append(row)

    row_num = len(csv_data)
    col_num = len(csv_data[0])

    data = np.zeros((row_num, col_num))
    for i in range(row_num):
        data[i, :] = np.array(list(map(float, csv_data[i])))
    return data


def get_best_arch_plot_RMSE(max_layers,max_neurons,step,save_ind):
    marker_list=['s','^','o','v']
    color_list = ['blue','red','black','orange']
    label_list=[]
    plt.figure(figsize=(10, 8))

    RMSE_mean = read_csv_to_np('RMSE_mean_ANN_arch_'+str(0)+'.csv')
    # np.savetxt('RMSE_mean_ANN_arch_'+str(save_ind)+'.csv', RMSE_mean, delimiter=',')
    for num_layers in range(max_layers):
        label_list.append('number of hidden layer = '+str(num_layers+1))
        node=(max_neurons-11)//step+1
        start_ind=num_layers*node
        end_ind=start_ind+node
        RMSE = RMSE_mean[start_ind:end_ind]
        plt.plot(range(11,max_neurons+1,step),RMSE,marker=marker_list[num_layers],c=color_list[num_layers])

    plt.tick_params(labelsize=40)  # axis number size
    font = {'family': 'Times New Roman', 'weight': 'normal', 'size': 40, }
    font2 = {'family': 'Times New Roman', 'weight': 'normal', 'size': 25, }
    plt.xlabel('Number of neurons per layer', font)
    plt.ylabel('Average RMSE of all trials', font)
    plt.legend(labels=label_list, loc='best', edgecolor='black', prop=font2)
    plt.ylim(0.2,0.4)
    plt.subplots_adjust(top=0.95, bottom=0.2, right=0.95, left=0.25)
    # plt.show()
    plt.savefig('RMSE_mean_ANN_arch_'+str(save_ind)+'.eps')
    plt.close()


get_best_arch_plot_RMSE(4,201,20,1)