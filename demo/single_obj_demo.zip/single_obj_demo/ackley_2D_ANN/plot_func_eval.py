import csv
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator


def read_csv_to_np(file_name):
    """
    read data from .csv and convert to numpy.array
    note: if you use np.loadtxt(), when the data have only one row or one column, the loaded data is not in the desired shape
    """
    csv_reader = csv.reader(open(file_name))
    csv_data = []
    for row in csv_reader:
        csv_data.append(row)

    row_num = len(csv_data)
    col_num = len(csv_data[0])

    data = np.zeros((row_num, col_num))
    for i in range(row_num):
        data[i, :] = np.array(list(map(float, csv_data[i])))
    return data


best_so_far=read_csv_to_np('./plot/best_so_far.csv')
func_eval_num=read_csv_to_np('./plot/func_eval_num.csv')

plt.plot(func_eval_num[0:-2], best_so_far, '--', marker='o', c='black')
plt.tick_params(labelsize=25)  # axis number size
fontXY = {'family': 'Times New Roman', 'weight': 'normal', 'size': 25, }
font_legend = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }
plt.xlabel('Number of function evaluation', fontXY)
plt.ylabel('Min actual y', fontXY)
# x_major_locator = MultipleLocator(5)  # 把x轴的刻度间隔设置为1，并存在变量里
# ax = plt.gca()
# ax.xaxis.set_major_locator(x_major_locator)
plt.subplots_adjust(top=0.95, bottom=0.2, left=0.15, right=0.98)
plt.xlim(-0.5,func_eval_num.max()+0.5)
# plt.show()
plt.savefig('./plot/func_eval_num.eps')
plt.close()



samp_num_list=read_csv_to_np('./plot/samp_num_list.csv')

plt.plot(range(1, best_so_far.shape[0] + 1), samp_num_list[1:-1], '-', marker='o', c='black')

plt.tick_params(labelsize=25)  # axis number size
fontXY = {'family': 'Times New Roman', 'weight': 'normal', 'size': 25, }
font_legend = {'family': 'Times New Roman', 'weight': 'normal', 'size': 15, }
plt.xlabel('Iteration', fontXY)
plt.ylabel('Sampling number', fontXY)
x_major_locator = MultipleLocator(5)  # 把x轴的刻度间隔设置为1，并存在变量里
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
plt.subplots_adjust(top=0.95, bottom=0.2, left=0.15, right=0.98)
# plt.show()
plt.savefig('./plot/samp_num.eps')
plt.close()
