# ==================================================
rootpath=r'F:\ljj\aa\demo' # your saopy file path
import sys
sys.path.append(rootpath) # you can directly import the modules in this folder
sys.path.append(rootpath+r'\saopy\surrogate_model')
sys.path.append(rootpath+r'\saopy')
# ==================================================

from saopy.sampling_plan import *
from saopy.function_evaluation.benchmark_func import *
from saopy.surrogate_model.ANN import *
# from saopy.surrogate_model.KRG import *
# from saopy.surrogate_model.RBF import *
from saopy.surrogate_model.surrogate_model import *
from saopy.surrogate_model import cross_validation
from saopy.optimization import *
from saopy.exploration import *
from saopy.exploitation import *
from saopy.adaptive_sequential_sampling import *
from saopy.database import *
from saopy.surro_valid_compare import *

import numpy as np
import time

# multiprocessing note: multiprocessing.Pool is applied to cross_validation and it must run after <if __name__ == '__main__':>
# multiprocessing note: you will not get the class attribute if you run the method in other process in parallel
# e.g. run <self.point=1> in other process, you will not get the self.point in the main process

if __name__ == '__main__':

    lower_bound = [100, 20, 0.3, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.2, 200, -145, 0.1, 0.3, 0.5, 0.5, 0.05, 0.35,
                   0.2, 0.65, 0.8, 200, 20, 0.2, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.2, 200, -80, 0.2, 0.05, 0.5,
                   0.5, 0.05, 0.35, 0.2, 0.65, 1.1, 400, 70, 0.2, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.1, 100, -55,
                   0.4, 0.05, 0.5, 0.5, 0.05, 0.35, 0.2, 0.65, 0.7, -464.0999, 86.7627]
    upper_bound = [400, 60, 0.7, 0.5, 0.95, 0.95, 0.35, 0.65, 0.6, 0.95, 0.8, 600, -105, 0.4, 0.5, 0.95, 0.95, 0.35,
                   0.65, 0.8, 0.95, 1.2, 500, 60, 0.7, 0.25, 0.95, 0.95, 0.35, 0.65, 0.6, 0.95, 0.5, 600, -40, 0.4, 0.5,
                   0.95, 0.95, 0.35, 0.65, 0.8, 0.95, 1.4, 800, 90, 0.7, 0.5, 0.95, 0.95, 0.35, 0.65, 0.9, 0.95, 0.9,
                   400, -15, 0.7, 0.4, 0.95, 0.95, 0.35, 0.65, 0.8, 0.95, 1.1, -379.7181, 106.0433]

    for iter in range(0,1):
        print(iter)

        if iter==0:
            print('get best ANN architecture with minimum RMSE')
            max_layers = 4
            max_neurons = 201
            step = 10
            num_fold = 3
            parallel_num = 30
            best_ANN_arch = get_best_arch(lower_bound, upper_bound, 'X.csv', 'y0.csv', max_layers, max_neurons, step, num_fold, parallel_num)
            get_best_arch_plot_RMSE(max_layers, max_neurons, step, 0)
            save_obj(best_ANN_arch, 'best_ANN_arch0')

        print('cross validation and get point max error')
        parallel_num=3; num_fold=3
        best_ANN_arch = load_obj('best_ANN_arch0')
        best_num_layers = best_ANN_arch.num_layers
        best_num_neurons = best_ANN_arch.neurons[0]
        surro_list=[]
        surro_list.append(ANN(num_layers=best_num_layers, num_neurons=best_num_neurons))
        # surro_list.append(RBF(num_centers=10))
        # surro_list.append(KRG()) # may take longer training time
        for surro in surro_list:
            surro.load_data(lower_bound, upper_bound,'X.csv','y0.csv')
            surro.normalize_all()
        cros_valid=cross_validation.random(surro_list,num_fold=num_fold)
        cros_valid.divide()
        best_ind = cros_valid.begin_cross_validation(parallel_num,obj_ind=0) # get best model index
        best_surro = surro_list[best_ind] # get best model
        best_surro.train(best_surro.normalized_X,best_surro.normalized_y) # train again using all samples
        save_obj(best_surro,'best_surro0') # save best model

        print('adaptive sequential sampling')
        surro_list = []
        surro_list.append(load_obj('best_surro0'))
        ass1 = ass(surro_list, iter, plot_flag=0)
        ass1.generate_new_X(number_optimized_X=10, number_exploitation_X=10, number_exploration_X=10)
        # ass1.plot(surro_list[0], [], iter)