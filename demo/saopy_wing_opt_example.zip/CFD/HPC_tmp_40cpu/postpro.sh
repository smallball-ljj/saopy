rootpath=`pwd`


for doe in $(seq 0 1 219)
do
  #no mesh & no model case
  if [ ! -f ${rootpath}/Mesh/$doe/cellsin.bin ]
  then
    echo "$doe,0,0,0" >> ${rootpath}/Result.csv
    continue
  fi


  #get last line cl cd
  clcount=0
  cdcount=0
  for cd in `awk '{print $10}' ${rootpath}/Cal/$doe/minfo1_e1`
  do
    ((cdcount=$cdcount+1))
  done
  for cl in `awk '{print $9}' ${rootpath}/Cal/$doe/minfo1_e1`
  do
    ((clcount=$clcount+1))
  done

  #get last second line cl cd
#  cl1count=0
#  cd1count=0
#  ((cdcount=$cdcount-1))
#  ((clcount=$clcount-1))
#  for cd1 in `awk '{print $10}' ${rootpath}/Cal/$doe/minfo1_e1`
#  do
#    ((cd1count=$cd1count+1))
#    if [ $cd1count -eq $cdcount ]
#    then
#      break
#    fi
#  done
#  for cl1 in `awk '{print $9}' ${rootpath}/Cal/$doe/minfo1_e1`
#  do
#    ((cl1count=$cl1count+1))
#    if [ $cl1count -eq $clcount ]
#    then
#      break
#    fi
#  done
  
  # format convert
  clconv="`echo $cl | awk '{printf("%f\n",$0)}'`"
  cdconv="`echo $cd | awk '{printf("%f\n",$0)}'`"
#  cl1conv="`echo $cl1 | awk '{printf("%f\n",$0)}'`"
#  cd1conv="`echo $cd1 | awk '{printf("%f\n",$0)}'`"
  

  target_cl=0.5
  dif="`echo "scale=10;$clconv-$target_cl"|bc `"
  
  
  if [ $(echo "$dif > 0.02" | bc) -eq 1 ]||[ $(echo "$dif < -0.02" | bc) -eq 1 ]
  then
#  	cdnew="`echo "scale=10;$cdconv+($cdconv-$cd1conv)/($clconv-$cl1conv)*($target_cl-$cl1conv)"|bc `"
    echo "$doe,0.5,"$clconv","$cdconv >> ${rootpath}/Result.csv
    continue
  fi

  #print cl cd
  echo "$doe,1,"$clconv","$cdconv >> ${rootpath}/Result.csv
  
done 
