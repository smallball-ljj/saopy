rootpath=`pwd`

for doe in $(seq 0 1 1000)

do
#skip if not exist file
if [ ! -f ${rootpath}/Mesh/$doe/cellsin.bin ]
then
continue
fi

cp -r ${rootpath}/Mesh/$doe ${rootpath}/Cal

cp -r ${rootpath}/Origin/. ${rootpath}/Cal/$doe

cd ${rootpath}/Cal/$doe

sbatch mpimcfd.slurm

done