import os
import csv
import numpy as np


def read_csv_to_np(file_name):
    """
    read data from .csv and convert to numpy.array
    note: if you use np.loadtxt(), when the data have only one row or one column, the loaded data is not in the desired shape
    """
    csv_reader = csv.reader(open(file_name))
    csv_data = []
    for row in csv_reader:
        csv_data.append(row)

    row_num = len(csv_data)
    col_num = len(csv_data[0])

    data = np.zeros((row_num, col_num))
    for i in range(row_num):
        data[i, :] = np.array(list(map(float, csv_data[i])))
    return data



X_new=read_csv_to_np('X_new.csv')
X_new_final=[] # final X_new will remove the results that don't exist in Cal because of undesirable model or with undesirable CFD results
y0_new=read_csv_to_np('Result.csv')
y0_new_final=[]

for i in range(y0_new.shape[0]):
    if y0_new[i, 1]==1:
        X_new_final.append(X_new[i, :])
        y0_new_final.append(y0_new[i, 3])

y0_new_final=np.array(y0_new_final)
y0_new_final.resize((y0_new_final.shape[0], 1))
np.savetxt('y0_new.csv', y0_new_final, delimiter=',')

np.savetxt('X_new.csv', np.array(X_new_final), delimiter=',')