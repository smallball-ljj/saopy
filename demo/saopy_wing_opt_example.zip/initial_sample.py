# ==================================================
rootpath=r'F:\ljj\saopy-master' # your saopy file path
import sys
sys.path.append(rootpath) # you can directly import the modules in this folder
sys.path.append(rootpath+r'\saopy\surrogate_model')
sys.path.append(rootpath+r'\saopy')
# ==================================================

from saopy.sampling_plan import *
from saopy.function_evaluation.benchmark_func import *
from saopy.surrogate_model.ANN import *
# from saopy.surrogate_model.KRG import *
# from saopy.surrogate_model.RBF import *
from saopy.surrogate_model.surrogate_model import *
from saopy.surrogate_model import cross_validation
from saopy.optimization import *
from saopy.exploration import *
from saopy.exploitation import *
from saopy.adaptive_sequential_sampling import *
from saopy.database import *
from saopy.surro_valid_compare import *

import numpy as np
import time

# multiprocessing note: multiprocessing.Pool is applied to cross_validation and it must run after <if __name__ == '__main__':>
# multiprocessing note: you will not get the class attribute if you run the method in other process in parallel
# e.g. run <self.point=1> in other process, you will not get the self.point in the main process

if __name__ == '__main__':

    lower_bound = [100, 20, 0.3, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.2, 200, -145, 0.1, 0.3, 0.5, 0.5, 0.05, 0.35,
                   0.2, 0.65, 0.8, 200, 20, 0.2, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.2, 200, -80, 0.2, 0.05, 0.5,
                   0.5, 0.05, 0.35, 0.2, 0.65, 1.1, 400, 70, 0.2, 0.05, 0.7, 0.5, 0.05, 0.35, 0.1, 0.65, 0.1, 100, -55,
                   0.4, 0.05, 0.5, 0.5, 0.05, 0.35, 0.2, 0.65, 0.7, -464.0999, 86.7627]
    upper_bound = [400, 60, 0.7, 0.5, 0.95, 0.95, 0.35, 0.65, 0.6, 0.95, 0.8, 600, -105, 0.4, 0.5, 0.95, 0.95, 0.35,
                   0.65, 0.8, 0.95, 1.2, 500, 60, 0.7, 0.25, 0.95, 0.95, 0.35, 0.65, 0.6, 0.95, 0.5, 600, -40, 0.4, 0.5,
                   0.95, 0.95, 0.35, 0.65, 0.8, 0.95, 1.4, 800, 90, 0.7, 0.5, 0.95, 0.95, 0.35, 0.65, 0.9, 0.95, 0.9,
                   400, -15, 0.7, 0.4, 0.95, 0.95, 0.35, 0.65, 0.8, 0.95, 1.1, -379.7181, 106.0433]

    print('initial sampling plan')
    number = 1360; dimension = 68

    # sp = optimal_lhs(number, dimension)
    # sp.begin_sampling(population=30, iterations=30)  # the larger the better, but will take long time

    sp = random_lhs(number, dimension)
    sp.begin_sampling()

    sp.inverse_norm(lower_bound, upper_bound)
    sp.output('X.csv')